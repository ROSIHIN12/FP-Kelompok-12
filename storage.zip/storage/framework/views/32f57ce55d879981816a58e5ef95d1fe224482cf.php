

<?php $__env->startSection('title', 'Create Registration'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Create Registration</h3>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('siswa.registrations.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nama_kursus">Course Name</label>
                        <input type="text" name="nama_kursus" id="nama_kursus" class="form-control" value="<?php echo e($course->nama); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="harga_kursus">Course Price</label>
                        <input type="text" name="harga_kursus" id="harga_kursus" class="form-control" value="<?php echo e($course->harga); ?>" readonly>
                    </div>
                    <input type="hidden" name="id_kursus" value="<?php echo e($course->id); ?>">
                    <button type="submit" class="btn btn-primary">Register</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\siswa\registrations\create.blade.php ENDPATH**/ ?>