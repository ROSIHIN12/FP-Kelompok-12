

<?php $__env->startSection('title', 'Payment Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Payment Details</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <table class="table table-borderless">
                            <tr>
                                <th>User</th>
                                <td><?php echo e($payment->user->nama); ?></td>
                            </tr>
                            <tr>
                                <th>Course Name</th>
                                <td><?php echo e($payment->kursus->nama); ?></td>
                            </tr>
                            <tr>
                                <th>Amount</th>
                                <td><?php echo e($payment->jumlah_pembayaran); ?></td>
                            </tr>
                            <tr>
                                <th>Payment Status</th>
                                <td><?php echo e($payment->status_pembayaran); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="border p-2">
                            <label for="bukti_pembayaran">Payment Proof</label>
                            <br>
                            <?php if($payment->bukti_pembayaran): ?>
                                <a href="<?php echo e(asset('storage/' . $payment->bukti_pembayaran)); ?>" target="_blank">
                                    <img src="<?php echo e(asset('storage/' . $payment->bukti_pembayaran)); ?>" alt="Payment Proof" class="img-fluid rounded" style="width: 200px; max-height: 400px; object-fit: cover;">
                                </a>
                            <?php else: ?>
                                <p>N/A</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\admin\payments\show.blade.php ENDPATH**/ ?>