

<?php $__env->startSection('title', 'Edit Course'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Edit Course</h3>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.courses.update', $course->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="form-group">
                        <label for="nama">Course Name</label>
                        <input type="text" name="nama" class="form-control" value="<?php echo e($course->nama); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="deskripsi">Description</label>
                        <textarea name="deskripsi" class="form-control" rows="3" required><?php echo e($course->deskripsi); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="harga">Price</label>
                        <input type="number" name="harga" class="form-control" value="<?php echo e($course->harga); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="gambar">Course Image</label>
                        <input type="file" name="gambar" class="form-control-file">
                        <?php if($course->gambar): ?>
                            <img src="<?php echo e(asset('storage/' . $course->gambar)); ?>" alt="Course Image" width="100">
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="user_id">Select Teacher</label>
                        <select name="user_id" class="form-control">
                            <option value="">-- Select Teacher --</option>
                            <?php $__currentLoopData = $gurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($guru->id); ?>" <?php echo e($course->user_id == $guru->id ? 'selected' : ''); ?>><?php echo e($guru->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Update Course</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\admin\courses\edit.blade.php ENDPATH**/ ?>