

<?php $__env->startSection('title', 'Detail Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Detail Pendaftaran</h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="nama">Nama Kursus</label>
                <p><?php echo e($registration->kursus->nama); ?></p>
            </div>
            <div class="form-group">
                <label for="status_pendaftaran">Status Pendaftaran</label>
                <p><?php echo e($registration->status_pendaftaran); ?></p>
            </div>
            <div class="form-group">
                <label for="status_kursus">Status Kursus</label>
                <p><?php echo e($registration->status_kursus); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/siswa/registrations/show.blade.php ENDPATH**/ ?>