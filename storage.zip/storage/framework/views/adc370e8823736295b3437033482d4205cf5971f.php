

<?php $__env->startSection('title', 'Ubah Informasi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Ubah Informasi</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.informations.update', $information->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="nama">Nama</label>
                    <input type="text" name="nama" id="nama" class="form-control" value="<?php echo e($information->nama); ?>" required>
                </div>
                <div class="form-group">
                    <label for="deskripsi">Deskripsi</label>
                    <textarea name="deskripsi" id="deskripsi" class="form-control" required><?php echo e($information->deskripsi); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="gambar">Gambar</label>
                    <input type="file" name="gambar" id="gambar" class="form-control-file">
                    <br>
                    <?php if($information->gambar): ?>
                        <img src="<?php echo e(asset('storage/' . $information->gambar)); ?>" alt="<?php echo e($information->nama); ?>" width="300">
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary">Ubah</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/admin/informations/edit.blade.php ENDPATH**/ ?>