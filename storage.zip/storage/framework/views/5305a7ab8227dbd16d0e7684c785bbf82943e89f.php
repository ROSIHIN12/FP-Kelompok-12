

<?php $__env->startSection('title', 'Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Pendaftaran</h3>
            </div>
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('siswa.registrations.index')); ?>" class="form-inline mb-3">
                    <div class="form-group">
                        <input type="text" name="search" class="form-control" placeholder="Cari dengan nama Kursus" value="<?php echo e(request()->search); ?>">
                    </div>
                    <button type="submit" class="btn btn-secondary ml-2">Cari</button>
                </form>
                <?php if($registrations->isEmpty()): ?>
                    <p>No registrations found.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Kursus</th>
                                    <th>Status Pendaftaran</th>
                                    <th>Status Kursus</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($registration->kursus->nama); ?></td>
                                        <td><?php echo e($registration->status_pendaftaran); ?></td>
                                        <td><?php echo e($registration->status_kursus); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('siswa.registrations.show', $registration->id)); ?>" class="btn btn-info btn-sm">Lihat</a>
                                            <form action="<?php echo e(route('siswa.registrations.destroy', $registration->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                            <?php if($registration->status_pendaftaran === 'menunggu pembayaran'): ?>
                                                <a href="<?php echo e(route('siswa.payments.create', ['registration_id' => $registration->id])); ?>" class="btn btn-success btn-sm">Bayar</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($registrations->links()); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/siswa/registrations/index.blade.php ENDPATH**/ ?>