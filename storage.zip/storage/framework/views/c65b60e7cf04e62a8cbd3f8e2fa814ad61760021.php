

<?php $__env->startSection('title', 'Materi Kursus'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card mb-3">
            <div class="card-header">
                <h3 class="card-title"><?php echo e($kursus->nama); ?></h3>
            </div>
            <div class="card-body">
                <p><?php echo e($kursus->deskripsi); ?></p>
                <h5 class="mt-4">Materials:</h5>
                <ul class="list-group" >
                    <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <h5><?php echo e($item->nama); ?></h5>
                            <p style="font-size: 0.875rem;"><?php echo nl2br(e($item->deskripsi)); ?></p>
                            <p style="font-size: 0.875rem;">
                                <strong>Silahkan Klik Link Berikut ini untuk mengikuti Kursus:</strong><br>
                                <a href="<?php echo e($item->materi_1); ?>" target="_blank"><?php echo e($item->materi_1); ?></a>
                            </p>
                            <p style="font-size: 0.875rem;">
                                <strong>Silahkan Klik Link Berikut ini untuk Mengisi Presensi dan Quesioner:</strong><br>
                                <a href="<?php echo e($item->materi_2); ?>" target="_blank"><?php echo e($item->materi_2); ?></a>
                            </p>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <a href="<?php echo e(route('siswa.my_courses.index')); ?>" class="btn btn-secondary mt-3">Kembali Ke Kursus</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/siswa/materi_kursus/show.blade.php ENDPATH**/ ?>