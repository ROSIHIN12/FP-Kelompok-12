

<?php $__env->startSection('title', 'Detail Materi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Detail Materi</h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="nama">Nama</label>
                <p><?php echo e($material->nama); ?></p>
            </div>
            <div class="form-group">
                <label for="course">Kursus</label>
                <p style="font-size: 0.875rem;"><?php echo e($material->kursus->nama); ?></p>
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi</label>
                <p style="font-size: 0.875rem;"><?php echo nl2br(e($material->deskripsi)); ?></p>
            </div>
            <div class="form-group">
                <label for="materi_1">Media Kursus</label>
                <p style="font-size: 0.875rem;">
                    <strong>Link Berikut ini untuk Kursus:</strong><br>
                    <a href="<?php echo e($material->materi_1); ?>" target="_blank"><?php echo e($material->materi_1); ?></a>
                </p>
            </div>
            <div class="form-group">
                <label for="materi_2">Presensi dan Quesioner</label>
                <p style="font-size: 0.875rem;">
                    <strong>Link Berikut ini untuk Presensi dan Quesioner:</strong><br>
                    <a href="<?php echo e($material->materi_2); ?>" target="_blank"><?php echo e($material->materi_2); ?></a>
                </p>
            </div>
        </div>                   
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/guru/materials/show.blade.php ENDPATH**/ ?>