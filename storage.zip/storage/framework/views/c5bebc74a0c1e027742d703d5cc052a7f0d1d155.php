<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
        <img src="<?php echo e(url('storage/' . config('app.logo', 'vendor/admin-lte/img/AdminLTELogo.png'))); ?>" alt="Application Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light"><?php echo e(config('app.name', 'Kursus Online')); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <?php if(Auth::check() && Auth::user()->foto_profil): ?>
                    <!-- Tampilkan gambar profil pengguna -->
                    <img src="<?php echo e(asset('storage/' . Auth::user()->foto_profil)); ?>" class="img-circle elevation-2" alt="User Image">
                <?php else: ?>
                    <!-- Tampilkan gambar profil default -->
                    <img src="<?php echo e(asset('vendor/admin-lte/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
                <?php endif; ?>
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo e(Auth::user()->nama ?? 'Guest'); ?></a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.users.index')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-users"></i>
                            <p>Pengguna</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.courses.index')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-book"></i>
                            <p>Kursus</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.registrations.index')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-file-alt"></i>
                            <p>Pendaftaran</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.payments.index')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-dollar-sign"></i>
                            <p>Pembayaran</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.informations.index')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-info-circle"></i>
                            <p>Informasi</p>
                        </a>
                    </li>
                    <!-- Tambahkan link ke halaman pengaturan -->
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.settings.edit')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-cogs"></i>
                            <p>Pengaturan</p>
                        </a>
                    </li>
                <?php elseif(Auth::check() && Auth::user()->role == 'guru'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('guru.dashboard')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('guru.courses')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-book"></i>
                            <p>Kursus Saya</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('guru.materials.index')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-file-alt"></i>
                            <p>Materi Kursus</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('guru.classes')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-chalkboard-teacher"></i>
                            <p>Kelas</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('guru.profile.show')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-user"></i>
                            <p>Profil</p>
                        </a>
                    </li>
                <?php elseif(Auth::check() && Auth::user()->role == 'siswa'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('siswa.dashboard')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('siswa.my_courses.index')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-book-reader"></i>
                            <p>Kursus Saya</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('siswa.available_courses')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-book-open"></i>
                            <p>Kursus Yang Tersedia</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('siswa.registrations.index')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-file-alt"></i>
                            <p>Pendaftaran</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('siswa.payments.index')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-dollar-sign"></i>
                            <p>Pembayaran</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('siswa.informations.index')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-info-circle"></i>
                            <p>Informasi</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('siswa.users.index')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-user"></i>
                            <p>Profil</p>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</aside>
<?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>