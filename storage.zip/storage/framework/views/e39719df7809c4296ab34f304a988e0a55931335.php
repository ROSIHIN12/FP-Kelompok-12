

<?php $__env->startSection('title', 'Ubah Profil'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Ubah Profil</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('siswa.profile.update')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" name="nama" id="nama" class="form-control" value="<?php echo e($user->nama); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" name="email" id="email" class="form-control" value="<?php echo e($user->email); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" id="password" class="form-control">
                            <small class="form-text text-muted">Kosongkan jika tidak ingin mengubah password.</small>
                        </div>
                        <div class="form-group">
                            <label for="password_confirmation">Konfirmasi Password</label>
                            <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="tingkat_pendidikan">Tingkat Pendidikan</label>
                            <input type="text" name="tingkat_pendidikan" id="tingkat_pendidikan" class="form-control" value="<?php echo e($user->tingkat_pendidikan); ?>">
                        </div>
                        <button type="submit" class="btn btn-warning">Simpan</button>
                    </div>
                    <div class="col-md-6 text-center">
                        <label for="foto_profil">Foto Profil</label>
                        <br>
                        <?php if($user->foto_profil): ?>
                            <img src="<?php echo e(asset('storage/' . $user->foto_profil)); ?>" alt="Profile Photo" class="img-fluid rounded" style="width: 200px; max-height: 300px; object-fit: cover;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('path/to/default/image.jpg')); ?>" alt="Profile Photo" class="img-fluid rounded" style="width: 200px; max-height: 300px; object-fit: cover;">
                        <?php endif; ?>
                        <br><br>
                        <input type="file" name="foto_profil" id="foto_profil" class="align-items-center">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/siswa/profil/edit.blade.php ENDPATH**/ ?>