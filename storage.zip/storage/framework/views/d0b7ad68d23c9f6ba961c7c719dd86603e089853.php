<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EnSa Course</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            position: relative; 
        }

        header .logo img {
            height: 50px;
        }

        header nav .nav-link {
            color: #000;
            font-weight: bold;
        }

        main .welcome-section {
            background-color: #e0e0e0;
            padding: 20px;
            border-radius: 10px;
        }

        main .welcome-section h1 {
            margin-top: 0;
        }

        main .welcome-section button {
            background-color: #6c63ff;
            color: #fff;
            border: none;
        }

        .card img {
            height: 150px;
            object-fit: cover;
        }

        footer address {
            font-style: normal;
        }

        .footer-logo img {
            height: 60px;
        }

        .back-to-top {
            position: fixed; /* Menjadikan posisi tetap agar tetap muncul saat menggulir */
            bottom: 20px; /* Jarak dari bagian bawah */
            right: 20px; /* Jarak dari bagian kanan */
            display: none; /* Mulai tersembunyi */
            z-index: 99; /* Menetapkan z-index agar muncul di atas konten */
            cursor: pointer; /* Menjadikan kursor berubah saat diarahkan */
        }

    </style>
</head>
<body>
    <header class="bg-light py-3 mb-4">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="logo d-flex align-items-center">
                <img src="<?php echo e(url('storage/' . config('app.logo', 'vendor/admin-lte/img/AdminLTELogo.png'))); ?>" alt="EnSa Course Logo" class="mr-2">
                <span>EnSa Course</span>
            </div>
            <nav class="d-flex w-100 justify-content-between align-items-center">
                <ul class="nav justify-content-between">
                    <li class="nav-item"><a href="#" class="nav-link">Home</a></li>
                    <li class="nav-item"><a href="#Courses" class="nav-link">Course</a></li>
                    <li class="nav-item"><a href="#teachers" class="nav-link">Teacher</a></li>
                    <li class="nav-item"><a href="#About" class="nav-link">About</a></li>
                </ul>
                <ul class="nav ml-auto">
                    <li class="nav-item"><a href="<?php echo e(route('login')); ?>" class="nav-link">Login</a></li>
                    <li class="nav-item"><a href="<?php echo e(route('register')); ?>" class="nav-link">Register</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <section class="text-center mb-5" style="background-color: #f0f0f0; border-radius: 10px; padding: 20px;">
            <h1>Welcome To EnSa Course</h1>
            <p>Join our online courses and start learning today.</p>
            <p>Learn from the best instructors in various fields. Whether you are looking to improve your skills, learn something new, or advance your career, we have the right course for you.</p>
            <a href="<?php echo e(route('register')); ?>" class="btn btn-primary">Get Started</a>
        </section>

        <section id="teachers" class="mb-5">
            <h2 class="text-center">Teachers</h2>
            <div class="row">
                <div class="col mb-4">
                    <div class="card">
                        <img src="<?php echo e(asset('storage/foto_teacher/naura_amara.jpg')); ?>" class="card-img-top" alt="Teacher Image">
                        <div class="card-body text-center">
                            <p class="card-title">NAURA AMARA</p>
                            <p class="card-text">FIGMA</p>
                        </div>
                    </div>
                </div>
                <div class="col mb-4">
                    <div class="card">
                        <img src="<?php echo e(asset('storage/foto_teacher/ahmad_muzaki.jpEg')); ?>" class="card-img-top" alt="Teacher Image">
                        <div class="card-body text-center">
                            <p class="card-title">AHMAD MUZAKI</p>
                            <p class="card-text">LARAVEL 9</p>
                        </div>
                    </div>
                </div>
                <div class="col mb-4">
                    <div class="card">
                        <img src="<?php echo e(asset('storage/foto_teacher/fatan_hamdan.png')); ?>" class="card-img-top" alt="Teacher Image">
                        <div class="card-body text-center">
                            <p class="card-title">FATAN HAMDAN</p>
                            <p class="card-text">HTML & CSS</p>
                        </div>
                    </div>
                </div>
                <div class="col mb-4">
                    <div class="card">
                        <img src="<?php echo e(asset('storage/foto_teacher/nova_ardani.jpg')); ?>" class="card-img-top" alt="Teacher Image">
                        <div class="card-body text-center">
                            <p class="card-title">NOVA ARDANI</p>
                            <p class="card-text">MYSQL</p>
                        </div>
                    </div>
                </div>
                <div class="col mb-4">
                    <div class="card">
                        <img src="<?php echo e(asset('storage/foto_teacher/robi_anggara.jpg')); ?>" class="card-img-top" alt="Teacher Image">
                        <div class="card-body text-center">
                            <p class="card-title bold">ROBI ANGGARA</p>
                            <p class="card-text">IONIC</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="Courses" class="mb-5">
            <h2 class="text-center">Courses</h2>
            <div class="row">
                <div class="col mb-4">
                    <div class="card">
                        <img src="path/to/placeholder.png" class="card-img-top" alt="Course Image">
                        <div class="card-body text-center">
                            <p class="card-title">HTML & CSS</p>
                            <p class="card-text">Basic Level</p>
                        </div>
                    </div>
                </div>
                <div class="col mb-4">
                    <div class="card">
                        <img src="path/to/placeholder.png" class="card-img-top" alt="Course Image">
                        <div class="card-body text-center">
                            <p class="card-title">LARAVEL</p>
                            <p class="card-text">Basic Level</p>
                        </div>
                    </div>
                </div>
                <div class="col mb-4">
                    <div class="card">
                        <img src="path/to/placeholder.png" class="card-img-top" alt="Course Image">
                        <div class="card-body text-center">
                            <p class="card-title">IONIC</p>
                            <p class="card-text">Basic Level</p>
                        </div>
                    </div>
                </div>
                <div class="col mb-4">
                    <div class="card">
                        <img src="path/to/placeholder.png" class="card-img-top" alt="Course Image">
                        <div class="card-body text-center">
                            <p class="card-title">MYSQL</p>
                            <p class="card-text">Basic Level</p>
                        </div>
                    </div>
                </div>
                <div class="col mb-4">
                    <div class="card">
                        <img src="path/to/placeholder.png" class="card-img-top" alt="Course Image">
                        <div class="card-body text-center">
                            <p class="card-title">FIGMA</p>
                            <p class="card-text">Basic Level</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section id="About" class="text-center mb-5" style="background-color: #f0f0f0; border-radius: 10px; padding: 20px;">
            <h2 class="text-center">About</h2>
            <p class="text-center">"Kursus online memberikan kesempatan bagi siapa saja untuk mengakses pembelajaran dari mana saja, memungkinkan fleksibilitas yang lebih besar dalam meningkatkan keterampilan dan pengetahuan."</p>
            <p class="text-center">"Tingkat partisipasi yang tinggi dan beragamnya materi yang tersedia membuat kursus online menjadi pilihan yang sangat populer bagi mereka yang ingin terus belajar dan berkembang, tanpa terbatas oleh waktu atau lokasi."</p>
        </section>
    </main>

    <footer class="bg-light py-4">
        <div class="container d-flex justify-content-between align-items-center">
            <address class="mb-0">
                <p>Alamat: Jl. Tegalgendu 10 Karawaci Jawa Barat</p>
                <p>Contact: ensacourse@gmail.com</p>
                <p>Hp: 085620222777</p>
                <p>Telepon: 0262 332 7464</p>
            </address>
            <div class="footer-logo d-flex align-items-center">
                <span>EnSa Course 2024</span>
                <img src="<?php echo e(url('storage/' . config('app.logo', 'vendor/admin-lte/img/AdminLTELogo.png'))); ?>" alt="EnSa Course Logo" class="ml-2">
            </div>
            <a class="back-to-top" href="#" aria-label="Kembali ke Atas">
                <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M36.3636 25.4546H26.9091V36L13.4546 22.5455L26.9091 9.09091V19.6364H36.3636V25.4546Z" fill="#6c63ff"/>
                </svg>
            </a>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script>
        $(document).ready(function(){
            // Saat pengguna menggulir halaman, periksa posisinya
            $(window).scroll(function(){
                if ($(this).scrollTop() > 100) { // Jika posisi guliran lebih besar dari 100px dari atas
                    $('.back-to-top').fadeIn(); // Munculkan tombol kembali ke atas
                } else {
                    $('.back-to-top').fadeOut(); // Sembunyikan tombol kembali ke atas
                }
            });

            // Saat tombol kembali ke atas diklik
            $('.back-to-top').click(function(){
                $('html, body').animate({scrollTop : 0},800); // Gulir halaman kembali ke atas dalam 800 milidetik
                return false;
            });
        });
    </script>
</body>
</html>
<?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\welcome.blade.php ENDPATH**/ ?>