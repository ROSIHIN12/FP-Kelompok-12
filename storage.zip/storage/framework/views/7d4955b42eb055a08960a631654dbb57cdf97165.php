

<?php $__env->startSection('title', 'Detail Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Detail Pembayaran</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 text-center">
                        <div class="border p-2">
                            <label for="bukti_pembayaran">Bukti Pembayaran</label>
                            <br>
                            <?php if($payment->bukti_pembayaran): ?>
                                <img src="<?php echo e(asset('storage/' . $payment->bukti_pembayaran)); ?>" alt="Payment Proof" class="img-fluid rounded" style="width: 100%; max-height: 400px; object-fit: cover;">
                            <?php else: ?>
                                <p>N/A</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="table-responsive">
                            <table class="table table-borderless">
                                <tr>
                                    <th>Nama Kursus</th>
                                    <td><?php echo e($payment->kursus->nama); ?></td>
                                </tr>
                                <tr>
                                    <th>Deskripsi</th>
                                    <td><?php echo e($payment->kursus->deskripsi); ?></td>
                                </tr>
                                <tr>
                                    <th>Jumlah Pembayaran</th>
                                    <td><?php echo e($payment->jumlah_pembayaran); ?></td>
                                </tr>
                                <tr>
                                    <th>Status Pembayaran</th>
                                    <td><?php echo e($payment->status_pembayaran); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/siswa/payments/show.blade.php ENDPATH**/ ?>