

<?php $__env->startSection('title', 'Detail Kelas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title">Detail Kelas: <?php echo e($course->nama); ?></h3>
                <form method="GET" action="<?php echo e(route('guru.classes.show', $course->id)); ?>" class="form-inline ml-auto">
                    <div class="form-group">
                        <input type="text" name="search" class="form-control" placeholder="Cari Nama atau Email" value="<?php echo e(request()->search); ?>">
                    </div>
                    <button type="submit" class="btn btn-secondary ml-2">Cari</button>
                </form>
            </div>
            <div class="card-body">
                <?php if($registrations->isEmpty()): ?>
                    <p>Tidak Ada Siswa Terdaftar Dikursus Ini.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Foto Profil</th>
                                    <th>Nama Siswa</th>
                                    <th>Email Siswa</th>
                                    <th>Status Kursus</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($registration->status_pendaftaran == 'berhasil' && $registration->status_kursus == 'Aktif'): ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td>
                                                <?php if($registration->user->foto_profil): ?>
                                                    <img src="<?php echo e(asset('storage/' . $registration->user->foto_profil)); ?>" alt="Profile Photo" class="rounded-circle" style="width: 50px; height: 50px; object-fit: cover;">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('path/to/default/image.jpg')); ?>" alt="Profile Photo" class="rounded-circle" style="width: 50px; height: 50px; object-fit: cover;">
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($registration->user->nama); ?></td>
                                            <td><?php echo e($registration->user->email); ?></td>
                                            <td><?php echo e($registration->status_kursus); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($registrations->links()); ?> <!-- Menambahkan navigasi paginasi -->
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/guru/classes/show.blade.php ENDPATH**/ ?>