

<?php $__env->startSection('title', 'Settings'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Settings</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.settings.update')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="app_name">Application Name</label>
                    <input type="text" name="app_name" id="app_name" class="form-control" value="<?php echo e(old('app_name', env('APP_NAME', 'Default App Name'))); ?>" required>
                </div>
                <div class="form-group">
                    <label for="app_logo">Application Logo</label>
                    <input type="file" name="app_logo" id="app_logo" class="form-control-file">
                    <?php if(env('APP_LOGO')): ?>
                        <?php
                            $logoPath = env('APP_LOGO', 'vendor/admin-lte/img/AdminLTELogo.png');
                            $logoUrl = Storage::url($logoPath);
                        ?>
                        <img src="<?php echo e(url('storage/' . config('app.logo', 'vendor/admin-lte/img/AdminLTELogo.png'))); ?>" alt="Application Logo" class="mt-2" width="200">
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary">Save</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\admin\settings\edit.blade.php ENDPATH**/ ?>