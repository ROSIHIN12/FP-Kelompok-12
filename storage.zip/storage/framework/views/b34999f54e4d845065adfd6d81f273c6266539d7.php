

<?php $__env->startSection('title', 'Dashboard Guru'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <!-- Card untuk jumlah kursus yang diampu -->
            <div class="col-md-6">
                <div class="card bg-info text-white mb-4">
                    <div class="card-body d-flex align-items-center">
                        <div class="icon-container">
                            <i class="fas fa-chalkboard-teacher fa-3x"></i>
                        </div>
                        <div class="ml-3">
                            <h3><?php echo e($totalCourses); ?></h3>
                            <a href="<?php echo e(route('guru.courses')); ?>" class="nav-link text-white p-0">
                                <p class="text-white">Total Kursus</p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card untuk jumlah materi yang dibuat -->
            <div class="col-md-6">
                <div class="card bg-success text-white mb-4">
                    <div class="card-body d-flex align-items-center">
                        <div class="icon-container">
                            <i class="fas fa-book fa-3x"></i>
                        </div>
                        <div class="ml-3">
                            <h3><?php echo e($totalMaterials); ?></h3>
                            <a href="<?php echo e(route('guru.materials.index')); ?>" class="nav-link text-white p-0">
                                <p class="text-white">Total Materi</p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <?php $__currentLoopData = $studentsPerCourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-body d-flex align-items-center">
                            <div class="icon-container">
                                <i class="fas fa-user-graduate fa-3x"></i>
                            </div>
                            <div class="ml-3">
                                <h4><?php echo e($course->nama); ?></h4>
                                <p class="text-white"><?php echo e($course->students_count); ?> Siswa</p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<style>
    .card {
        border: 1px solid #ddd;
        border-radius: 10px;
        transition: transform 0.3s, box-shadow 0.3s;
    }

    .card:hover {
        transform: translateY(-10px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    }

    .card-body {
        display: flex;
        align-items: center;
    }

    .card-body h3, .card-body h4 {
        font-size: 2rem;
        font-weight: bold;
        margin: 0;
    }

    .card-body p {
        font-size: 1.2rem;
        margin: 0;
    }

    .icon-container {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 80px;
        height: 80px;
    }

    .icon-container i {
        font-size: 3rem;
    }

    .ml-3 {
        margin-left: 1rem;
    }

    .bg-info {
        background-color: #17a2b8 !important;
    }

    .bg-success {
        background-color: #28a745 !important;
    }

    .bg-warning {
        background-color: #ffc107 !important;
    }

    .bg-danger {
        background-color: #dc3545 !important;
    }

    .bg-light {
        background-color: #f8f9fa !important;
    }

    .nav-link {
        padding: 0;
    }
</style>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/guru/dashboard.blade.php ENDPATH**/ ?>