

<?php $__env->startSection('title', 'My Courses'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title">My Courses</h3>
            </div>
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('siswa.my_courses.index')); ?>" class="form-inline mb-3">
                    <div class="form-group">
                        <input type="text" name="search" class="form-control" placeholder="Search by course name or description" value="<?php echo e(request()->search); ?>">
                    </div>
                    <button type="submit" class="btn btn-secondary ml-2">Search</button>
                </form>
                <?php if($registrations->isEmpty()): ?>
                    <p>No courses found.</p>
                <?php else: ?>
                    <div class="row">
                        <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mb-4 d-flex align-items-stretch">
                                <div class="card shadow-sm w-100 border">
                                    <img src="<?php echo e($registration->kursus->gambar ? asset('storage/' . $registration->kursus->gambar) : asset('path/to/default/image.jpg')); ?>" class="card-img-top" alt="<?php echo e($registration->kursus->nama); ?>" style="height: 150px; object-fit: cover;">
                                    <div class="card-body d-flex flex-column">
                                        <h5 class="card-title"><?php echo e($registration->kursus->nama); ?></h5>
                                        <p class="card-text"><?php echo e($registration->kursus->deskripsi); ?></p>
                                        <p class="card-text"><strong>Status:</strong> <?php echo e($registration->status_kursus); ?></p>
                                        <a href="<?php echo e(route('siswa.my_courses.materi', $registration->kursus->id)); ?>" class="btn btn-info mt-auto">Show</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php echo e($registrations->links()); ?> <!-- Menambahkan navigasi paginasi -->
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\siswa\my_courses\index.blade.php ENDPATH**/ ?>