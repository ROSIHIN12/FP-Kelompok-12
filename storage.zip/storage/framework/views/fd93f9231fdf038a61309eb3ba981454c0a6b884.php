

<?php $__env->startSection('title', 'Course Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Course Details</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <table class="table table-borderless">
                            <tr>
                                <th>Course Name</th>
                                <td><?php echo e($course->nama); ?></td>
                            </tr>
                            <tr>
                                <th>Description</th>
                                <td><?php echo e($course->deskripsi); ?></td>
                            </tr>
                            <tr>
                                <th>Price</th>
                                <td><?php echo e($course->harga); ?></td>
                            </tr>
                            <tr>
                                <th>Teacher</th>
                                <td><?php echo e($course->guru ? $course->guru->nama : 'N/A'); ?></td>
                            </tr>
                        </table>
                        <a href="<?php echo e(route('admin.courses.index')); ?>" class="btn btn-secondary">Back to Courses</a>
                    </div>
                    <div class="col-md-4 text-center">
                        <?php if($course->gambar): ?>
                            <div class="border p-2">
                                <label for="gambar">Image</label>
                                <br>
                                <img src="<?php echo e(asset('storage/' . $course->gambar)); ?>" alt="Course Image" class="img-fluid rounded" style="width: 200px; max-height: 400px; object-fit: cover;">
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\admin\courses\show.blade.php ENDPATH**/ ?>