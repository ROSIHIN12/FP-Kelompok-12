

<?php $__env->startSection('title', 'Edit Material'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Edit Material</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('guru.materials.update', $material->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="nama">Nama</label>
                    <input type="text" name="nama" id="nama" class="form-control" value="<?php echo e($material->nama); ?>" required>
                </div>
                <div class="form-group">
                    <label for="deskripsi">Deskripsi</label>
                    <textarea name="deskripsi" id="deskripsi" class="form-control" required><?php echo e($material->deskripsi); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="materi_1">Materi 1</label>
                    <textarea name="materi_1" id="materi_1" class="form-control" required><?php echo e($material->materi_1); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="materi_2">Materi 2</label>
                    <textarea name="materi_2" id="materi_2" class="form-control"><?php echo e($material->materi_2); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="id_kursus">Course</label>
                    <select name="id_kursus" id="id_kursus" class="form-control">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($course->id); ?>" <?php echo e($material->id_kursus == $course->id ? 'selected' : ''); ?>><?php echo e($course->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\guru\materials\edit.blade.php ENDPATH**/ ?>