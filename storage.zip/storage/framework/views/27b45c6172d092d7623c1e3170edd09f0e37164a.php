<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <!-- Add other navbar items here -->
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            <a class="nav-link" id="datetime"></a>
        </li>
        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a></li>
        <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a></li>
        <?php else: ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    Logout
                </a>
            </li>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
            
        <?php endif; ?>
    </ul>
</nav>

<script>
    function updateDateTime() {
        const options = { weekday: 'long', year: 'numeric', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit', second: '2-digit' };
        const now = new Date().toLocaleDateString('en-US', options);
        document.getElementById('datetime').innerText = now;
    }

    setInterval(updateDateTime, 1000);
    updateDateTime(); // initial call to set the datetime immediately
</script>
<?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\partials\navbar.blade.php ENDPATH**/ ?>