<footer class="main-footer">
    <strong>&copy; 2024 <a href="#">Ensa Course</a>.</strong> All rights reserved.
</footer>
<?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/partials/footer.blade.php ENDPATH**/ ?>