

<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <!-- First Row of Cards -->
        <div class="col-lg-6 col-md-6 mb-4">
            <div class="card text-white bg-danger card-size">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <i class="fas fa-database fa-3x"></i>
                        <div class="text-right">
                            <h3><?php echo e($totalUsers); ?></h3>
                            <p class="text-white" >Total Pengguna</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-md-6 mb-4">
            <div class="card text-white bg-success card-size">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <i class="fas fa-book fa-3x"></i>
                        <div class="text-right">
                            <h3><?php echo e($totalCourses); ?></h3>
                            <p class="text-white" >Total Kursus</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6 col-md-6 mb-4">
            <div class="card text-white bg-info card-size">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <i class="fas fa-clipboard-list fa-3x"></i>
                        <div class="text-right">
                            <h3><?php echo e($totalRegistrations); ?></h3>
                            <p class="text-white" >Total Pendaftaran</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-md-6 mb-4">
            <div class="card text-white bg-warning card-size">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <i class="fas fa-dollar-sign fa-3x"></i>
                        <div class="text-right">
                            <h3><?php echo e($totalPayments); ?></h3>
                            <p class="text-white" >Total Pembayaran</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header bg-info text-white">
                    Pendaftaran Terbaru
                </div>
                <div class="card-body">
                    <ul class="list-group">
                        <?php $__currentLoopData = $recentRegistrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <?php echo e($registration->user->nama); ?> Telah Mendaftar Untuk <?php echo e($registration->kursus->nama); ?> Pada Tanggal <?php echo e($registration->created_at->format('d M Y')); ?>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header bg-success text-white">
                    Pembayaran Terbaru
                </div>
                <div class="card-body">
                    <ul class="list-group">
                        <?php $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <?php echo e($payment->user->nama); ?> Telah Membayar Sejumlah <?php echo e($payment->jumlah_pembayaran); ?> Untuk <?php echo e($payment->kursus->nama); ?> Pada Tanggal <?php echo e($payment->created_at->format('d M Y')); ?>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    var ctxDailySales = document.getElementById('dailySalesChart').getContext('2d');
    var dailySalesChart = new Chart(ctxDailySales, {
        type: 'line',
        data: {
            labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
            datasets: [{
                label: 'Sales',
                data: [65, 59, 80, 81, 56, 55, 40],
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        }
    });

    var ctxEmailSubscriptions = document.getElementById('emailSubscriptionsChart').getContext('2d');
    var emailSubscriptionsChart = new Chart(ctxEmailSubscriptions, {
        type: 'bar',
        data: {
            labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
            datasets: [{
                label: 'Subscriptions',
                data: [28, 48, 40, 19, 86, 27, 90],
                backgroundColor: 'rgba(153, 102, 255, 0.2)',
                borderColor: 'rgba(153, 102, 255, 1)',
                borderWidth: 1
            }]
        }
    });

    var ctxCompletedTasks = document.getElementById('completedTasksChart').getContext('2d');
    var completedTasksChart = new Chart(ctxCompletedTasks, {
        type: 'line',
        data: {
            labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
            datasets: [{
                label: 'Tasks',
                data: [35, 49, 60, 31, 56, 65, 40],
                backgroundColor: 'rgba(255, 206, 86, 0.2)',
                borderColor: 'rgba(255, 206, 86, 1)',
                borderWidth: 1
            }]
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>