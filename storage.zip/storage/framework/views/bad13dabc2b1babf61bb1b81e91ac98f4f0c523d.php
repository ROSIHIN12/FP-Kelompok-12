

<?php $__env->startSection('title', 'Create Payment'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Create Payment</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('siswa.payments.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id_user" value="<?php echo e(auth()->user()->id); ?>">
                <input type="hidden" name="id_kursus" value="<?php echo e($registration->kursus->id); ?>">
                <div class="form-group">
                    <label for="nama_kursus">Course</label>
                    <input type="text" id="nama_kursus" class="form-control" value="<?php echo e($registration->kursus->nama); ?>" disabled>
                </div>
                <div class="form-group">
                    <label for="jumlah_pembayaran">Amount</label>
                    <input type="number" name="jumlah_pembayaran" id="jumlah_pembayaran" class="form-control" value="<?php echo e($registration->kursus->harga); ?>" required readonly>
                </div>
                <div class="form-group">
                    <label for="bukti_pembayaran">Payment Proof</label>
                    <input type="file" name="bukti_pembayaran" id="bukti_pembayaran" class="form-control-file">
                </div>
                <button type="submit" class="btn btn-primary">Save</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\siswa\payments\create.blade.php ENDPATH**/ ?>