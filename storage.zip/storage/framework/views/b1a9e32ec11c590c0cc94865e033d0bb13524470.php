

<?php $__env->startSection('title', 'Create User'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Create User</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.users.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nama">Name</label>
                    <input type="text" name="nama" id="nama" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="password_confirmation">Confirm Password</label>
                    <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="role">Role</label>
                    <select name="role" id="role" class="form-control">
                        <option value="admin">Admin</option>
                        <option value="guru">Guru</option>
                        <option value="siswa">Siswa</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="tingkat_pendidikan">Education Level</label>
                    <input type="text" name="tingkat_pendidikan" id="tingkat_pendidikan" class="form-control">
                </div>
                <div class="form-group">
                    <label for="foto_profil">Profile Photo</label>
                    <input type="file" name="foto_profil" id="foto_profil" class="form-control-file">
                </div>
                <button type="submit" class="btn btn-primary">Save</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\admin\users\create.blade.php ENDPATH**/ ?>