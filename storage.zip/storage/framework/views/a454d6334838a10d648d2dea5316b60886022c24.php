<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header text-bold"><?php echo e(__('Selamat Datang')); ?> <?php echo e(Auth::user()->nama ?? 'Guest'); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <h4><?php echo e(__('Informasi Terbaru')); ?></h4>
                    <?php $__currentLoopData = $informations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $information): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-info" role="alert">
                            <?php if($information->gambar): ?>
                                <img src="<?php echo e(asset('storage/' . $information->gambar)); ?>" alt="<?php echo e($information->nama); ?>" class="img-fluid mx-auto d-block" style="max-width: 400px;">
                            <?php else: ?>
                                <p>N/A</p>
                            <?php endif; ?>
                            <p><?php echo e($information->nama); ?></p>
                            <p><?php echo e($information->deskripsi); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\home.blade.php ENDPATH**/ ?>