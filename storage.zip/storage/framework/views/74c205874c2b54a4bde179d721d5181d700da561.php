

<?php $__env->startSection('title', 'Buat Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Buat Pembayaran</h3>
        </div>
        <div class="container mt-5">
            <h3 class="text-center"><strong>Pilih Metode Pembayaran</strong></h3>
            <br>
            <div class="row justify-content-center">
            <div class="col-md-5 payment-method">
                <h4>Transfer Bank</h4>
                <br>
                <div class="d-flex align-items-center mb-3">
                <img src="<?php echo e(asset('storage/logo_bank/bri.png')); ?>" alt="BRI Logo">
                <div class="ml-5">
                    <p>3676 7647 9857 6743</p>
                    <p>Ensa Course</p>
                </div>
                </div>
                <div class="d-flex align-items-center mb-3">
                <img src="<?php echo e(asset('storage/logo_bank/bni.png')); ?>" alt="BNI Logo">
                <div class="ml-5">
                    <p>14426327718</p>
                    <p>Ensa Course</p>
                </div>
                </div>
                <div class="d-flex align-items-center">
                <img src="<?php echo e(asset('storage/logo_bank/bca.png')); ?>" alt="BCA Logo">
                <div class="ml-5">
                    <p>53437623736</p>
                    <p>Ensa Course</p>
                </div>
                </div>
            </div>
            <div class="col-md-5 payment-method">
                <h4>E-Wallet</h4>
                <br>
                <img src="<?php echo e(asset('storage/logo_bank/dana.png')); ?>" alt="Dana Logo">
                <p>085694582312</p>
                <p>Ensa Course</p>
            </div>
            </div>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('siswa.payments.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id_user" value="<?php echo e(auth()->user()->id); ?>">
                <input type="hidden" name="id_kursus" value="<?php echo e($registration->kursus->id); ?>">
                <div class="form-group">
                    <label for="nama_kursus">Nama Kursus</label>
                    <input type="text" id="nama_kursus" class="form-control" value="<?php echo e($registration->kursus->nama); ?>" disabled>
                </div>
                <div class="form-group">
                    <label for="jumlah_pembayaran">Jumlah Pembayaran</label>
                    <input type="number" name="jumlah_pembayaran" id="jumlah_pembayaran" class="form-control" value="<?php echo e($registration->kursus->harga); ?>" required readonly>
                </div>
                <div class="form-group">
                    <label for="bukti_pembayaran">Bukti Pembayaran</label>
                    <input type="file" name="bukti_pembayaran" id="bukti_pembayaran" class="form-control-file">
                </div>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/siswa/payments/create.blade.php ENDPATH**/ ?>