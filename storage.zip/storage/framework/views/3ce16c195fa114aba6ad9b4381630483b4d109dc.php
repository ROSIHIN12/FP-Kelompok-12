

<?php $__env->startSection('title', 'Ubah Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Ubah Pembayaran</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.payments.update', $payment->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="id_user">Pengguna</label>
                    <select name="id_user" id="id_user" class="form-control">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e($payment->id_user == $user->id ? 'selected' : ''); ?>><?php echo e($user->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="id_kursus">Kursus</label>
                    <select name="id_kursus" id="id_kursus" class="form-control">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($course->id); ?>" <?php echo e($payment->id_kursus == $course->id ? 'selected' : ''); ?>><?php echo e($course->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="jumlah_pembayaran">Jumlah Pembayaran</label>
                    <input type="number" name="jumlah_pembayaran" id="jumlah_pembayaran" class="form-control" value="<?php echo e($payment->jumlah_pembayaran); ?>" required>
                </div>
                <div class="form-group">
                    <label for="bukti_pembayaran">Bukti Pembayaran</label>
                    <input type="file" name="bukti_pembayaran" id="bukti_pembayaran" class="form-control-file">
                    <br>
                    <?php if($payment->bukti_pembayaran): ?>
                        <img src="<?php echo e(asset('storage/' . $payment->bukti_pembayaran)); ?>" alt="Payment Proof" width="100">
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="status_pembayaran">Status Pembayaran</label>
                    <select name="status_pembayaran" id="status_pembayaran" class="form-control">
                        <option value="sedang diperiksa" <?php echo e($payment->status_pembayaran == 'sedang diperiksa' ? 'selected' : ''); ?>>Sedang Diperiksa</option>
                        <option value="berhasil" <?php echo e($payment->status_pembayaran == 'berhasil' ? 'selected' : ''); ?>>Berhasil</option>
                        <option value="dikembalikan" <?php echo e($payment->status_pembayaran == 'dikembalikan' ? 'selected' : ''); ?>>Dikembalikan</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Ubah</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/admin/payments/edit.blade.php ENDPATH**/ ?>