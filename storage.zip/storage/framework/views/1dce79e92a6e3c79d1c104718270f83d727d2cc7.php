

<?php $__env->startSection('title', 'Course Materials'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><?php echo e($registration->kursus->nama); ?></h3>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <img src="<?php echo e($registration->kursus->gambar ? asset('storage/' . $registration->kursus->gambar) : asset('path/to/default/image.jpg')); ?>" class="img-fluid rounded" alt="<?php echo e($registration->kursus->nama); ?>">
            </div>
            <div class="mb-3">
                <h5><strong>Description:</strong></h5>
                <p><?php echo e($registration->kursus->deskripsi); ?></p>
            </div>
            <div class="mb-3">
                <h5><strong>Status:</strong></h5>
                <p><?php echo e($registration->status_pendaftaran); ?></p>
            </div>
            <div>
                <h5><strong>Materials:</strong></h5>
                <ul>
                    <?php $__currentLoopData = $registration->kursus->materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($materi->nama); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="d-flex justify-content-end mt-3">
                <a href="<?php echo e(route('siswa.my_courses.index')); ?>" class="btn btn-secondary">Back to My Courses</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\siswa\my_courses\show.blade.php ENDPATH**/ ?>