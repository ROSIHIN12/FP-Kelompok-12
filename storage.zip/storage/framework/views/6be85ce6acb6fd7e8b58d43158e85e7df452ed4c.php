

<?php $__env->startSection('title', 'Courses'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Courses</h3>
                <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn btn-primary float-right">Add Course</a>
            </div>
            <div class="card-body">
                <?php if($courses->isEmpty()): ?>
                    <p>No courses found.</p>
                <?php else: ?>
                    <div class="row">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mb-4">
                                <div class="card h-100 shadow-sm border">
                                    <img src="<?php echo e($course->gambar ? asset('storage/' . $course->gambar) : asset('path/to/default/image.jpg')); ?>" class="card-img-top" alt="<?php echo e($course->nama); ?>" style="height: 150px; object-fit: cover;">
                                    <div class="card-body d-flex flex-column">
                                        <h5 class="card-title"><?php echo e($course->nama); ?></h5>
                                        <p class="card-text"><?php echo e(Str::limit($course->deskripsi, 100)); ?></p>
                                        <p class="card-text"><strong>Price:</strong> <?php echo e($course->harga); ?></p>
                                        <p class="card-text"><strong>Teacher:</strong> <?php echo e($course->guru ? $course->guru->nama : 'N/A'); ?></p>
                                        <div class="mt-auto">
                                            <a href="<?php echo e(route('admin.courses.show', $course->id)); ?>" class="btn btn-info btn-sm">Show</a>
                                            <a href="<?php echo e(route('admin.courses.edit', $course->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                            <form action="<?php echo e(route('admin.courses.destroy', $course->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php echo e($courses->links()); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\admin\courses\index.blade.php ENDPATH**/ ?>