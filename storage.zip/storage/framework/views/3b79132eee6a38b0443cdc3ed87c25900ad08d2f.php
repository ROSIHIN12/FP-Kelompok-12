

<?php $__env->startSection('title', 'Dashboard Siswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <!-- Card untuk kursus yang bisa diikuti -->
        <div class="col-md-6 mb-4">
            <div class="card bg-info text-white h-100">
                <div class="card-body d-flex align-items-center">
                    <i class="fas fa-book-open fa-3x mr-3"></i>
                    <div>
                        <h3><?php echo e($availableCourses); ?></h3>
                        <a href="<?php echo e(route('siswa.available_courses')); ?>" class="nav-link text-white p-0">
                            <p class="text-white">Kursus Yang Tersedia</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card untuk kursus yang sedang diikuti -->
        <div class="col-md-6 mb-4">
            <div class="card bg-success text-white h-100">
                <div class="card-body d-flex align-items-center">
                    <i class="fas fa-book-reader fa-3x mr-3"></i>
                    <div>
                        <h3><?php echo e($ongoingCourses); ?></h3>
                        <a href="<?php echo e(route('siswa.my_courses.index')); ?>" class="nav-link text-white p-0">
                            <p class="text-white">Kursus Sedang Berlangsung</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<style>
.card {
    border: 1px solid #ddd;
    border-radius: 10px;
    transition: transform 0.3s, box-shadow 0.3s;
}

.card:hover {
    transform: translateY(-10px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
}

.card-body {
    display: flex;
    align-items: center;
}

.card-body h3 {
    font-size: 2rem;
    font-weight: bold;
    margin: 0;
}

.card-body p {
    font-size: 1.2rem;
    margin: 0;
}

.icon-container {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 80px;
    height: 80px;
}

.icon-container i {
    font-size: 3rem;
}

.ml-3 {
    margin-left: 1rem;
}

.bg-info {
    background-color: #17a2b8 !important;
}

.bg-success {
    background-color: #28a745 !important;
}

.border-info {
    border-color: #17a2b8 !important;
}

.border-success {
    border-color: #28a745 !important;
}

.nav-link {
    padding: 0;
}
</style>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/siswa/dashboard.blade.php ENDPATH**/ ?>