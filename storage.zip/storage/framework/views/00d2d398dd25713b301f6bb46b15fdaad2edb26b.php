

<?php $__env->startSection('title', 'Edit Registration'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Edit Registration</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.registrations.update', $registration->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="id_user">User</label>
                    <select name="id_user" id="id_user" class="form-control">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e($registration->id_user == $user->id ? 'selected' : ''); ?>><?php echo e($user->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="id_kursus">Course</label>
                    <select name="id_kursus" id="id_kursus" class="form-control">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($course->id); ?>" <?php echo e($registration->id_kursus == $course->id ? 'selected' : ''); ?>><?php echo e($course->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="status_pendaftaran">Registration Status</label>
                    <select name="status_pendaftaran" id="status_pendaftaran" class="form-control">
                        <option value="menunggu pembayaran" <?php echo e($registration->status_pendaftaran == 'menunggu pembayaran' ? 'selected' : ''); ?>>Menunggu Pembayaran</option>
                        <option value="berhasil" <?php echo e($registration->status_pendaftaran == 'berhasil' ? 'selected' : ''); ?>>Berhasil</option>
                        <option value="gagal" <?php echo e($registration->status_pendaftaran == 'gagal' ? 'selected' : ''); ?>>Gagal</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="status_kursus">Course Status</label>
                    <select name="status_kursus" id="status_kursus" class="form-control">
                        <option value="Aktif" <?php echo e($registration->status_kursus == 'Aktif' ? 'selected' : ''); ?>>Aktif</option>
                        <option value="Belum Aktif" <?php echo e($registration->status_kursus == 'Belum Aktif' ? 'selected' : ''); ?>>Belum Aktif</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\admin\registrations\edit.blade.php ENDPATH**/ ?>