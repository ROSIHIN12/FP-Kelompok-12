

<?php $__env->startSection('title', 'Available Courses'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title">Available Courses</h3>
            </div>
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('siswa.available_courses')); ?>" class="form-inline mb-3">
                    <div class="form-group">
                        <input type="text" name="search" class="form-control" placeholder="Search courses" value="<?php echo e(request()->search); ?>">
                    </div>
                    <button type="submit" class="btn btn-secondary ml-2">Search</button>
                </form>
                <div class="row">
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-4 d-flex align-items-stretch">
                            <div class="card shadow-sm w-100 border">
                                <img src="<?php echo e($course->gambar ? asset('storage/' . $course->gambar) : asset('path/to/default/image.jpg')); ?>" class="card-img-top" alt="<?php echo e($course->nama); ?>" style="height: 150px; object-fit: cover;">
                                <div class="card-body d-flex flex-column">
                                    <h5 class="card-title"><?php echo e($course->nama); ?></h5>
                                    <p class="card-text"><?php echo e($course->deskripsi); ?></p>
                                    <p class="card-text"><strong>Price:</strong> <?php echo e($course->harga); ?></p>
                                    <div class="card-text">
                                        <strong>Rating:</strong>
                                        <?php
                                            $rating = round($course->average_rating); // Pastikan average_rating tersedia di $course
                                        ?>
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <?php if($i <= $rating): ?>
                                                <span class="fa fa-star checked"></span>
                                            <?php else: ?>
                                                <span class="fa fa-star"></span>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </div>
                                    <a href="<?php echo e(route('siswa.registrations.create', ['id_kursus' => $course->id])); ?>" class="btn btn-primary mt-auto">Register</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo e($courses->links()); ?> <!-- Menambahkan navigasi paginasi -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .fa-star {
        color: lightgray;
    }
    .fa-star.checked {
        color: gold;
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\siswa\available_courses.blade.php ENDPATH**/ ?>