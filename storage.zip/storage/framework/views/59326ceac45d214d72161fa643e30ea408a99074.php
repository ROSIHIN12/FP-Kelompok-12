

<?php $__env->startSection('title', 'Material Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Material Details</h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="nama">Nama</label>
                <p><?php echo e($material->nama); ?></p>
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi</label>
                <p><?php echo e($material->deskripsi); ?></p>
            </div>
            <div class="form-group">
                <label for="materi_1">Materi 1</label>
                <p><?php echo e($material->materi_1); ?></p>
            </div>
            <div class="form-group">
                <label for="materi_2">Materi 2</label>
                <p><?php echo e($material->materi_2); ?></p>
            </div>
            <div class="form-group">
                <label for="course">Course</label>
                <p><?php echo e($material->kursus->nama); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\guru\materials\show.blade.php ENDPATH**/ ?>