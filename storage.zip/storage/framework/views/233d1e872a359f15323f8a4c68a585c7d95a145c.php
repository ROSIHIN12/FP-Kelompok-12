

<?php $__env->startSection('title', 'My Profile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">My Profile</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <table class="table table-borderless">
                            <tr>
                                <th>Name</th>
                                <td><?php echo e($user->nama); ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo e($user->email); ?></td>
                            </tr>
                            <tr>
                                <th>Role</th>
                                <td><?php echo e($user->role); ?></td>
                            </tr>
                            <tr>
                                <th>Education Level</th>
                                <td><?php echo e($user->tingkat_pendidikan); ?></td>
                            </tr>
                        </table>
                        <a href="<?php echo e(route('guru.profile.edit', $user->id)); ?>" class="btn btn-warning">Edit Profile</a>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="border p-2">
                            <label for="foto_profil">Profile Photo</label>
                            <br>
                            <img src="<?php echo e($user->foto_profil ? asset('storage/' . $user->foto_profil) : asset('path/to/default/image.jpg')); ?>" alt="Profile Photo" class="img-fluid rounded" style="width: 200px; max-height: 400px; object-fit: cover;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views\guru\profile\show.blade.php ENDPATH**/ ?>