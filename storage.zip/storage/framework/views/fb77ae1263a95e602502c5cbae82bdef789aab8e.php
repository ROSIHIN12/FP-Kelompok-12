

<?php $__env->startSection('title', 'Kursus'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Kursus</h3>
                <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn btn-primary float-right">Tambah Kursus</a>
            </div>
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('admin.courses.index')); ?>" class="form-inline mb-3">
                    <div class="form-group">
                        <input type="text" name="search" class="form-control" placeholder="Cari Kursus" value="<?php echo e(request()->search); ?>">
                    </div>
                    <button type="submit" class="btn btn-secondary ml-2">Cari</button>
                </form>
                <?php if($courses->isEmpty()): ?>
                    <p>No courses found.</p>
                <?php else: ?>
                    <div class="row">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mb-4">
                                <div class="card shadow-sm border" style="max-width: 18rem;">
                                    <img src="<?php echo e($course->gambar ? asset('storage/' . $course->gambar) : asset('path/to/default/image.jpg')); ?>" class="card-img-top" alt="<?php echo e($course->nama); ?>" style="height: 100px; object-fit: cover;">
                                    <div class="card-body d-flex flex-column" style="padding: 10px;">
                                        <h5 class="card-title" style="font-size: 1rem;"><?php echo e($course->nama); ?></h5>
                                        <p class="card-text" style="font-size: 0.875rem; margin-bottom: 0.25rem;"><?php echo e(Str::limit($course->deskripsi, 100)); ?></p>
                                        <p class="card-text" style="font-size: 0.875rem; margin-bottom: 0.25rem;"><strong>Harga:</strong> <?php echo e($course->harga); ?></p>
                                        <p class="card-text" style="font-size: 0.875rem; margin-bottom: 0.25rem;"><strong>Guru:</strong> <?php echo e($course->guru ? $course->guru->nama : 'N/A'); ?></p>
                                        <div class="card-text course-rating" style="font-size: 0.875rem; margin-bottom: 0.25rem;">
                                            <strong>Rating:</strong>
                                            <?php
                                                $rating = round($course->average_rating); // Pastikan average_rating tersedia di $course
                                            ?>
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <?php if($i <= $rating): ?>
                                                    <span class="fa fa-star checked"></span>
                                                <?php else: ?>
                                                    <span class="fa fa-star"></span>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                        </div>
                                        <div class="mt-auto">
                                            <a href="<?php echo e(route('admin.courses.show', $course->id)); ?>" class="btn btn-info btn-sm" style="font-size: 0.875rem; padding: 5px 10px;">Lihat</a>
                                            <a href="<?php echo e(route('admin.courses.edit', $course->id)); ?>" class="btn btn-warning btn-sm" style="font-size: 0.875rem; padding: 5px 10px;">Ubah</a>
                                            <form action="<?php echo e(route('admin.courses.destroy', $course->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" style="font-size: 0.875rem; padding: 5px 10px;">Hapus</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php echo e($courses->appends(['search' => request()->search])->links()); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .course-rating .fa-star {
        color: gold !important;
    }
    .course-rating .fa-star.checked {
        color: light !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\FINAL PROJECT SEMESTER 4\KursusOnlineke3\resources\views/admin/courses/index.blade.php ENDPATH**/ ?>